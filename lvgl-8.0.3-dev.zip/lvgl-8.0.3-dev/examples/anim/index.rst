
Start animation on an event 
""""""""""""""""""""""""""""

.. lv_example:: anim/lv_example_anim_1
  :language: c

Playback animation
"""""""""""""""""""
.. lv_example:: anim/lv_example_anim_2
  :language: c

  
